# LXK0301 永远滴神
# actions均已不能用，勿Fork

[给自己的TP点](https://github.com/VidocqH/jd_scripts/blob/master/docker/crontab_list.sh)

[SHARECODES](https://github.com/VidocqH/jd_scripts/blob/master/githubAction.md)

[LXK yyds](https://gitee.com/lxk0301/jd_scripts/tree/master/)

[可迷核实崔](https://github.com/VidocqH/jd_scripts/commits/master)

~~If you know how to setup, you can use~~

Fork would let the action's state be 'disabled_fork', here is how to re-enable actions:

```bash
node i @octokit/rest
node actions_openner.js owner repo
# Example:
node actions_openner.js vidocqh jd_actions_vi
```
